package Controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import proyectoCalculadora.VentanaPrincipal;
import proyectoCalculadora.VentanaContrase�a;

public class ManejadorEventos implements ActionListener {
	
	private VentanaPrincipal ventana;
	VentanaContrase�a ventana2;
	
	public ManejadorEventos(VentanaPrincipal ventana) {
		this.ventana = ventana;
	}
		
		public void actionPerformed(ActionEvent e) {
			
			
			if(e.getSource()==ventana.getBoton5()) {
			JOptionPane.showMessageDialog(null, "FUNCIONALIDAD NO DISPONIBLE", "", JOptionPane.WARNING_MESSAGE);
		}
			if(e.getSource()==ventana.getBoton6()) {
				ventana2 = new VentanaContrase�a(this);
				ventana2.setVisible(true); 
			}
			String contrase�a = String.copyValueOf(ventana2.getContrase�a().getPassword());
			
			int division = Integer.parseInt(ventana.getCajaTexto1().getText()) / Integer.parseInt(ventana.getCajaTexto2().getText());
			if (contrase�a.equals("123")) {
				ventana.getEtiqueta3().setText(String.valueOf("Resultado: " + division));
			}
}
	
	
		}
