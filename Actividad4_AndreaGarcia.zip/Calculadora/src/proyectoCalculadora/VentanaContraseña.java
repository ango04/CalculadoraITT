package proyectoCalculadora;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import Controlador.ManejadorEventos;

public class VentanaContrase�a extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JLabel etiqueta1;
	private JPasswordField passwordField;
	

	public JPasswordField getContrase�a() {
		return passwordField;
	}

	public void setContrase�a(JPasswordField contrase�a) {
		this.passwordField = contrase�a;
	}


	public VentanaContrase�a(ManejadorEventos controlador) {
		setForeground(Color.CYAN);
		getContentPane().setForeground(Color.CYAN);
		
		setBounds(100, 100, 555, 195);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(new Color(0, 191, 255));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		contentPanel.setLayout(null);
		{
			JLabel etiqueta1 = new JLabel("Introduzca una contrase�a para realizar la operaci�n: ");
			etiqueta1.setHorizontalAlignment(SwingConstants.CENTER);
			etiqueta1.setForeground(Color.WHITE);
			etiqueta1.setFont(new Font("Tahoma", Font.BOLD, 18));
			etiqueta1.setBounds(12, 13, 513, 50);
			contentPanel.add(etiqueta1);
		}
		
		passwordField = new JPasswordField();
		passwordField.setBounds(167, 63, 157, 37);
		contentPanel.add(passwordField);
			JPanel buttonPane = new JPanel();
			buttonPane.setBackground(new Color(0, 191, 255));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			{
				JButton okButton = new JButton("Aceptar");
				okButton.setActionCommand("Aceptar");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			}
			{
				JButton cancelButton = new JButton("Cancelar");
				cancelButton.setActionCommand("Cancelar");
				buttonPane.add(cancelButton);
			}
		}
	public void establecerTexto(String nombreUsuario) {
		etiqueta1.setText(nombreUsuario);
	}
	}


