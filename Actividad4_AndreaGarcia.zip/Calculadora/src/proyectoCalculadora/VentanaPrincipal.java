package proyectoCalculadora;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Controlador.ManejadorEventos;

public class VentanaPrincipal extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public JButton boton1, boton2, boton3, boton4, boton5, boton6;
	private JTextField cajaTexto1, cajaTexto2;
	private JLabel etiqueta1, etiqueta2, etiqueta3, logo, contrase�a;
	
	public JButton getBoton1() {
		return boton1;
	}
	public void setBoton1(JButton boton1) {
		this.boton1 = boton1;
	}
	public JButton getBoton2() {
		return boton2;
	}
	public void setBoton2(JButton boton2) {
		this.boton2 = boton2;
	}
	public JButton getBoton3() {
		return boton3;
	}
	public void setBoton3(JButton boton3) {
		this.boton3 = boton3;
	}
	public JButton getBoton4() {
		return boton4;
	}
	public void setBoton4(JButton boton4) {
		this.boton4 = boton4;
	}
	public JButton getBoton5() {
		return boton5;
	}
	public void setBoton5(JButton boton5) {
		this.boton5 = boton5;
	}
	public JButton getBoton6() {
		return boton6;
	}
	public void setBoton6(JButton boton6) {
		this.boton6 = boton6;
	}
	public JTextField getCajaTexto1() {
		return cajaTexto1;
	}
	public void setCajaTexto1(JTextField cajaTexto1) {
		this.cajaTexto1 = cajaTexto1;
	}
	public JTextField getCajaTexto2() {
		return cajaTexto2;
	}
	public void setCajaTexto2(JTextField cajaTexto2) {
		this.cajaTexto2 = cajaTexto2;
	}
	public JLabel getEtiqueta1() {
		return etiqueta1;
	}
	public void setEtiqueta1(JLabel etiqueta1) {
		this.etiqueta1 = etiqueta1;
	}
	public JLabel getEtiqueta2() {
		return etiqueta2;
	}
	public void setEtiqueta2(JLabel etiqueta2) {
		this.etiqueta2 = etiqueta2;
	}
	public JLabel getEtiqueta3() {
		return etiqueta3;
	}
	public void setEtiqueta3(JLabel etiqueta3) {
		this.etiqueta3 = etiqueta3;
	}
	public JLabel getLogo() {
		return logo;
	}
	public void setLogo(JLabel logo) {
		this.logo = logo;
	}
	public JLabel getContrase�a() {
		return contrase�a;
	}
	public void setContrase�a(JLabel contrase�a) {
		this.contrase�a = contrase�a;
	}
	
	
	public VentanaPrincipal() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(550,800);
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage("alarm-panel.png"));
		setTitle("Calculadora ITT");
		setLocationRelativeTo(null);
		setLayout(null);
		inicializarComponentes();
		setVisible(true);
		
	}
	private void inicializarComponentes() {
		
		getContentPane().setBackground(new Color(51,204,255));
		
		Image img = new ImageIcon("calculadora1.jpg").getImage();
		logo = new JLabel(new ImageIcon(img.getScaledInstance(130,130, Image.SCALE_SMOOTH)));
		logo.setBounds(225, 50, 130, 130);
		add(logo);
		
		try {
			Font fuente = Font.createFont(Font.TRUETYPE_FONT, getClass().getResourceAsStream("GengRimbaRegular.ttf"));
			etiqueta1 = new JLabel("N�mero 1: ");
			etiqueta1.setBounds(120, 210, 150, 50);
			etiqueta1.setFont(fuente.deriveFont(Font.BOLD, 35f));
			etiqueta1.setForeground(Color.WHITE);
			
			etiqueta2 = new JLabel("N�mero 2: ");
			etiqueta2.setBounds(120, 290, 150, 50);
			etiqueta2.setFont(fuente.deriveFont(Font.BOLD, 35f));
			etiqueta2.setForeground(Color.WHITE);
			
			etiqueta3 = new JLabel("Resultado: ");
			etiqueta3.setBounds(160, 600, 200, 50);
			etiqueta3.setFont(fuente.deriveFont(Font.BOLD, 35f));
			etiqueta3.setForeground(Color.WHITE);
			
			
			cajaTexto1 = new JTextField();
			cajaTexto1.setBounds(270,220,100,30);
			cajaTexto1.setBorder(null);
			cajaTexto1.setFont(fuente.deriveFont(Font.BOLD, 35f));
			cajaTexto1.setForeground(new Color(51,204,255));
			
			cajaTexto2 = new JTextField();
			cajaTexto2.setBounds(270,300,100,30);
			cajaTexto2.setBorder(null);
			cajaTexto2.setFont(fuente.deriveFont(Font.BOLD, 35f));
			cajaTexto2.setForeground(new Color(51,204,255));
					
			boton1 = new JButton("Sumar");
			boton1.setBounds(90, 380, 190, 50);
			boton1.setFont(fuente.deriveFont(Font.BOLD, 35f));
			boton1.setForeground(new Color(51,204,255));
			boton1.setBackground(Color.WHITE);
			boton1.setBorder(null);
			
			boton2 = new JButton("Restar");
			boton2.setBounds(300, 380, 190, 50);
			boton2.setFont(fuente.deriveFont(Font.BOLD, 35f));
			boton2.setForeground(new Color(51,204,255));
			boton2.setBackground(Color.WHITE);
			boton2.setBorder(null);
			
			boton3 = new JButton("Multiplicar");
			boton3.setBounds(90, 440, 190, 50);
			boton3.setFont(fuente.deriveFont(Font.BOLD, 35f));
			boton3.setForeground(new Color(51,204,255));
			boton3.setBackground(Color.WHITE);
			boton3.setBorder(null);
			
			boton4 = new JButton("Dividir");
			boton4.setBounds(300, 440, 190, 50);
			boton4.setFont(fuente.deriveFont(Font.BOLD, 35f));
			boton4.setForeground(new Color(51,204,255));
			boton4.setBackground(Color.WHITE);
			boton4.setBorder(null);
			
			boton5 = new JButton("Ra�z Cuadrada");
			boton5.setBounds(90, 500, 190, 50);
			boton5.setFont(fuente.deriveFont(Font.BOLD, 35f));
			boton5.setForeground(new Color(51,204,255));
			boton5.setBackground(Color.WHITE);
			boton5.setBorder(null);
			
			boton6 = new JButton("Ra�z C�bica");
			boton6.setBounds(300, 500, 190, 50);
			boton6.setFont(fuente.deriveFont(Font.BOLD, 35f));
			boton6.setForeground(new Color(51,204,255));
			boton6.setBackground(Color.WHITE);
			boton6.setBorder(null);
			
			add(etiqueta1);
			add(etiqueta2);
			add(etiqueta3);
			add(cajaTexto1);
			add(cajaTexto2);
			add(boton1);
			add(boton2);
			add(boton3);
			add(boton4);
			add(boton5);
			add(boton6);
			
			
		} catch (FontFormatException e1) {
			
			e1.printStackTrace();
		} catch (IOException e1) {
			
			e1.printStackTrace();}
		
	boton1.addActionListener(new ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
			int suma = Integer.parseInt(cajaTexto1.getText()) + Integer.parseInt(cajaTexto2.getText());
			etiqueta3.setText(String.valueOf("Resultado: " + suma));
		}
	});	
	boton2.addActionListener(new ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
			int resta = Integer.parseInt(cajaTexto1.getText()) - Integer.parseInt(cajaTexto2.getText());
			etiqueta3.setText(String.valueOf("Resultado: " + resta));
		}
	});	
	boton3.addActionListener(new ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
			int multiplicacion = Integer.parseInt(cajaTexto1.getText()) * Integer.parseInt(cajaTexto2.getText());
			etiqueta3.setText(String.valueOf("Resultado: " + multiplicacion));
		}
	});	
	boton4.addActionListener(new ActionListener() {
		
		public void actionPerformed(ActionEvent e) {
			int division = Integer.parseInt(cajaTexto1.getText()) / Integer.parseInt(cajaTexto2.getText());
			etiqueta3.setText(String.valueOf("Resultado: " + division));
		}
	});	
	}
		public void establecerManejador(ManejadorEventos manejador) {
			
			boton5.addActionListener(manejador);
			boton6.addActionListener(manejador);
			
		}
		
}
